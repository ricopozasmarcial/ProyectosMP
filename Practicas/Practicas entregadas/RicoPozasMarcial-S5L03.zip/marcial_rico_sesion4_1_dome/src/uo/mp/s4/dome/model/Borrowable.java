package uo.mp.s4.dome.model;

public interface Borrowable {
	
	boolean borrow();
	void giveBack();
	boolean isAvailableToBorrow();
	
	
	
}
