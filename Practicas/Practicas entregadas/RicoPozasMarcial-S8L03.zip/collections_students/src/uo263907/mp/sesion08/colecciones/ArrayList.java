package uo263907.mp.sesion08.colecciones;

public class ArrayList implements List{
	
	private Object[] elements;
	private int numberOfElements;
	
	public ArrayList(int capacity) {
		elements=new Object[capacity];
		numberOfElements = 0;
	}
	
	public ArrayList() {
		new ArrayList();
	}
	/**
	 * metodo que indica el tama�o del ArrayList
	 */
	@Override
	public int size() {
		return size();
	}

	/**
	 * metodo que indica si el array esta vacio o no
	 */
	@Override
	public boolean isEmpty() {
		return size()==0;
	}

	/**
	 * metodo que indica si un Array contiene el objeto
	 * 
	 * @param o, un Object que indica el objeto que se quiere saber si esta en la coleccion o no
	 */
	@Override
	public boolean contains(Object o) {
		boolean bool = false;
		for(int i= 0; i<size();i++) {
			if(get(i)==o)
				bool = true;
		}
		return bool;
	}

	/**
	 * metodo que a�ade un elemento
	 * 
	 * @param element, un object que indica el objeto a introducir
	 */
	@Override
	public boolean add(Object element) {
		boolean bool = false;
		if (size() >= elements.length)
			moreMemory(size()+1);
			elements[size()] = element;
			numberOfElements++;
			bool = true;
		return bool;
	}

	/**
	 * metodo que borra un elemento
	 * 
	 * @param o, un object que indica el objeto a borrar
	 */
	@Override
	public boolean remove(Object o) {
		boolean bool = false;
		checkElement(o);
		checkState();
		int position = this.indexOf(o);
		if (position != -1)		
			bool = true;
		return bool;
	}

	/**
	 * metodo que obtiene el objeto indicado por el index
	 * 
	 * @param index, un int que indica la posicion del objeto a devolver
	 */
	@Override
	public Object get(int index) {
		return elements[index];
	}

	/**
	 * metodo que establece un determinado objeto en una posicion determinada
	 * 
	 * @param index, un int que indica el indice donde introducir el objeto
	 * @param element, un object que indica el elemento a introducir
	 */
	@Override
	public Object set(int index, Object element) {
		elements[index]=element;
		return element;
	}

	/**
	 * metodo que a�ade un determinado objeto en una posicion determinada
	 * 
	 * @param index, un int que indica el indice donde introducir el objeto
	 * @param element, un objetc que indica el elemento a introducir
	 */
	@Override
	public void add(int index, Object element) {
		if (size() >= elements.length)
			moreMemory(size()+1);
			for(int i=size(); i>index; i--)
			elements[i] = elements[i-1];
			elements[index] = element;
			numberOfElements++;
	}

	
	/**
	 * metodo que elimina un elemento en la posicion pasada como parametro
	 * 
	 * @param index, un int que indica el indice en el que eliminar el objeto
	 * @return 
	 */
	@Override
	public Object remove(int index) {
		for(int i=0;i<size();i++) {
			if(get(i)==get(index))
				remove(i);
		}
		return remove(index);
	}

	@Override
	public void clear() {
		for(int i=0; i<size();i++) {
			remove(i);
		}

	}

	/**
	 * metodo que devuelve la posicion del objeto pasado como parametro
	 * 
	 * @param o, un Object que expresa el elemento del que queremos saber su posicion
	 */
	@Override
	public int indexOf(Object o) {
		int contador = 0;
		for(int i = 0;i<size(); i++ ) {
			if(get(i)!= o)
				contador++;
		}
		return contador;
	}
	
	
	private void moreMemory(int numElem) {
		if (numElem > elements.length) {
		Object[] aux = new Object[Math.max( numElem,
		2*elements.length)];
		System.arraycopy(elements, 0, aux, 0,
		elements.length);
		elements=aux;}
		}
	
	private void checkElement(Object object){
		if ( object == null)			
			throw new IllegalArgumentException("Error el par�metro no puede ser null");	}
	
	private void checkState(){
		if (isEmpty())			
			throw new IllegalStateException("Error la lista esta vacia");}
}
