/**
 * 
 */
package uo.mp.s5.shapes.model;

import java.io.PrintStream;

/**
 * @author UO263907
 *
 */
public interface Drawable {
	void draw(PrintStream out);
}
