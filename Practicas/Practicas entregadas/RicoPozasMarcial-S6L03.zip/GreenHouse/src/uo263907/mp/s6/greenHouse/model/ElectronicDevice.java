/**
 * 
 */
package uo263907.mp.s6.greenHouse.model;

import java.io.PrintStream;

/**
 * @author UO263907
 *
 */
public interface ElectronicDevice {
	
	void check(PrintStream out);
	
}
