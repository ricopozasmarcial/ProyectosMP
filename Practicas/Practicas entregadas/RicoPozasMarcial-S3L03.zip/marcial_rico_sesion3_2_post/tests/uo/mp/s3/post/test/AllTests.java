package uo.mp.s3.post.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ MessageTest.class, PhotoTest.class, PostTest.class, TheWebTest.class })
public class AllTests {

}
