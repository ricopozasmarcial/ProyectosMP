package uo.mp.s3.post.test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.*;
import uo.mp.s3.post.model.Post;

public class PostTest {

	private Post p1;
	private ArrayList<String> comentarios;
	
	@Before
	public void setUp(){
		
		comentarios = new ArrayList<String>();
		comentarios.add("como mola");
		comentarios.add("me encanta");
		p1 = new Post(comentarios, 'q');
	}

	@Test
	public void testPost() {
		
		//caso1: se construye el objeto correctamente
		assertEquals(comentarios, p1.getCommentList());
		assertEquals('q', p1.getIdentifier());
		
		
		//caso2: se construye el objeto con un id erroneo
		try{
			p1 = new Post(comentarios, ' ');
			fail();
		}
		catch(IllegalArgumentException iea) {
			assertEquals("parametro invalido", iea.getMessage());
		}
		
		//caso3 se introduce un objeto con un arrayList null
		try{
			p1 = new Post(null, 'q');
			fail();
		}
		catch(IllegalArgumentException iea) {
			assertEquals("parametro invalido", iea.getMessage());
		}
	}
	
	@Test
	public void testAdd() {
		//se introduce cualquier tipo de comentario
		String c1 = "hola esto es una prueba";
		p1.add(c1);
		assertEquals(c1, p1.getCommentList().get(2));
	}
}
