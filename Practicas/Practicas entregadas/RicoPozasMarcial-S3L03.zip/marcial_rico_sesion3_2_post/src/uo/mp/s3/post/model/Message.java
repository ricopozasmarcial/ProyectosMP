package uo.mp.s3.post.model;

import java.util.ArrayList;

public class Message extends Post {
	
	//atributos
	private String texto;
	
	/**
	 * constructor con parametros de objetos de la clase Message
	 * 
	 * @param texto, un string que indica el texto
	 * @param comentario, un String que indica un comentario
	 * @param idUsuario, un char que indica el identificador del usuario
	 */
	public Message(String texto ,ArrayList<String> comentarios, char idUsuario) {
		super(comentarios, idUsuario);
		setTexto(texto);
	}
	
	/**
	 * metodo set del atributo texto
	 * 
	 * @param titulo, un String que asigna el texto del mensaje
	 */
	private void setTexto(String texto) {
		if(texto== " " || texto == null) {
			throw new IllegalArgumentException("Parametro invalido");
		}
		else {
			this.texto = texto;
		}
	}
	
	/**
	 * metodo get del atributo texto
	 * 
	 * @return el valor de texto
	 */	
	public String getTexto(){
		return this.texto;
	}
	
	
}
