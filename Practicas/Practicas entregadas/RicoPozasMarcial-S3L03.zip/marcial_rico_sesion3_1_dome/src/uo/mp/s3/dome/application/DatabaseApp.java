/**
 * 
 */
package uo.mp.s3.dome.application;



import uo.mp.s3.dome.model.Cd;
import uo.mp.s3.dome.model.Database;
import uo.mp.s3.dome.model.Dvd;
import uo.mp.s3.dome.model.VideoGame;
import uo.mp.s3.dome.model.VideoGame.Platforms;

/**
 * @author Power Service
 *
 */
public class DatabaseApp {
	private Database db;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new DatabaseApp().run();

	}
	public void run() {
		db = new Database();
		Cd cd1 = new Cd("Night Visions", "Imagine Dragons", 14, 120);
		Cd cd2 = new Cd("Meteroa", "Linkin Park", 10, 100);
		Cd cd3 = new Cd("La Veneno Greatest Hits ", "Cristina la veneno", 54, 320);
		Dvd dvd1 = new Dvd("Titanic", "James Cameron", 150);
		Dvd dvd2 = new Dvd("Sharknado", "Pedro Almodovar", 550);
		Dvd dvd3 = new Dvd("Titanica", "Yeims Camaron de la isla", 650);
		VideoGame vg1 = new VideoGame("CoD", "Marcial Rico", "Buen Juego", Platforms.XBOX, 4, "ACTIVISION");
		VideoGame vg2 = new VideoGame("Child of Light", "Marcial Rico", "Gran Juego", Platforms.NINTENDO, 1, "UBISFOT");
		VideoGame vg3 = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO");
		db.add(cd1);
		db.add(cd2);
		db.add(cd3);
		db.add(dvd1);
		db.add(dvd2);
		db.add(dvd3);
		db.add(vg1);
		db.add(vg2);
		db.add(vg3);
		System.out.println("EL numero de objetos adquiridos es : " + db.numberOfItemsOwned());
		db.printResponsables(System.out);
		db.list(System.out);
	}
}
