package uo263907.mp.sesion08.test;

import static org.junit.Assert.*;

import uo263907.mp.sesion08.colecciones.LinkedList;
import uo263907.mp.sesion08.colecciones.List;

public class LinkedListTest extends ListTest {

	@Override
	public List createList() {
		return new LinkedList();
	}

}
