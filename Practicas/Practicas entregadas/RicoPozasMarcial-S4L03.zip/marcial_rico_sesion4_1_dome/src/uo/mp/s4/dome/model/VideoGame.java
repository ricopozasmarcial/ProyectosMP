/**
 * 
 */
package uo.mp.s4.dome.model;

import java.io.PrintStream;

/**
 * @author Power Service
 *
 */
public class VideoGame extends Item {
	
	public enum Platforms {XBOX, NINTENDO, PLAYSTATION};
	
	//Atributos
	private String author;
	private String owner;
	private String review;
	private int numberOfPlayers;
	private Platforms platform;
	
	/**
	 * Constructor de objetos de la clase VideoGame
	 * @param theTitle
	 * @param time
	 * @param author, un String que indica el autor del juego
	 * @param owner, un String que indica el due�o del juego
	 * @param review, un String que anota un comentario
	 * @param numberOfPlayers, un entero que indica el numero de jugadores
	 */
	public VideoGame(String theTitle, String theOwner,String theReview, Platforms thePlatform, int theNumberOfPlayers, String theAuthor, double price) {
		super(theTitle, price);
		setOwner(theOwner);
		setReview(theReview);
		setNumberOfPlayers(theNumberOfPlayers);
		setPlatform(thePlatform);
		setAuthor(theAuthor);
	}
	

	/**
	 * metodo set del enum platforms
	 * @param thePlatform, un enumerado que indica la plataforma
	 */
	private void setPlatform(Platforms thePlatform) {
		if(thePlatform== null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.platform = thePlatform;
		}
		
	}
	
	/**
	 * metodo set del atributo numberOfPlayers
	 * @param theNumberOfPlayers, un entero que indica el numero de jugadores
	 */
	private void setNumberOfPlayers(int theNumberOfPlayers) {
		if(theNumberOfPlayers <= 0) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.numberOfPlayers = theNumberOfPlayers;
		}
	}
	
	/**
	 * metodo set del atributo review
	 * @param theReview, un string que indica el comentario sobre el juego
	 */
	private void setReview(String theReview) {
		if((theReview == null) ||(theReview == "" )) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.review = theReview;
		}
		
	}
	
	/**
	 * metodo set del atributo Owner
	 * @param theOwner, un string que indica el due�o del juego
	 */
	private void setOwner(String theOwner) {
		if((theOwner == null) ||(theOwner == "" )) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.owner = theOwner;
		
	}
	}
	
	/**
	 * metodo set del atributo author
	 * @param theAuthor, un String que asigna el nombre del autor del juego
	 */
	private void setAuthor(String theAuthor){
		if(theAuthor== null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.author = theAuthor;
		}
	}
	
	/**
	 * metodo get del atributo author
	 * @return el valor de author
	 */
	public String getAuthor() {
		return this.author;
	}
	
	/**
	 * metodo get del atributo platform
	 * @return el valor de platform
	 */
	public Platforms getPlatform() {
		return this.platform;
	}
	
	/**
	 * metodo get del atributo owner
	 * @return el valor de owner
	 */
	public String getOwner() {
		return this.owner;
	}
	
	/**
	 * metodo get del atributo numberOfPlayers
	 * @return el valor de numberOfPlayers
	 */
	public int getNumberOfPlayers() {
		return this.numberOfPlayers;
	}
	
	/**
	 * metodo get del atributo review
	 * @return el valor de review
	 */
	public String getReview() {
		return this.review;
	}
	
	/**
	 * metodo printResponsable de la clase VideoGame
	 */
	public void printResponsable(PrintStream out) {
		out.println(getAuthor() + " ");
	}
	
	/**
	 * metodo print de la clase Videogame
	 */
	public void print(PrintStream out) {

		out.print("VIDEOGAME: ");
		super.print(out);
		out.println("Author " + getAuthor());
		out.println("Plataform " + getPlatform());
		out.println("Number of players " + getNumberOfPlayers());
		out.println("Reviews :" + getReview());
		out.println("");
	}


	@Override
	public boolean isEqualTo(Item item) {
		if(item instanceof VideoGame) {
			if(item.getTitle().equals(this.getTitle()) && ((VideoGame) item).getAuthor().equals(this.getAuthor()))
				return true; 
			else
				return false;
		}
		return false;
	}


	@Override
	public double calculatePrice(Item item) {
		if(item instanceof VideoGame) {
			return (item.getPrice()*(1.1));
		}
		return 0;
	}


	@Override
	public String code(Item item) {
		if(item instanceof VideoGame) {
			String sCadena = getTitle().substring(0, 3);
			String true_false = new String();
			if(item.getOwn()==true) {
				true_false = "T";
			}
			else {
				true_false = "F";
			}
			sCadena = sCadena+true_false;
			return sCadena;
		}
		else
			return null;
	}
}
