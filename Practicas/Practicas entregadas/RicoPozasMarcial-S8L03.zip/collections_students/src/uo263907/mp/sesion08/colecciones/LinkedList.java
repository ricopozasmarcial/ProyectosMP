package uo263907.mp.sesion08.colecciones;

public class LinkedList implements List {
	
	private Node head;
	private int numberOfElements;
	
	class Node{
		 Object element;
		 Node next;
		 
		 Node(Object element, Node next){
			 this.element = element;
			 this.next = next;
		 }
	}
	
	@Override
	public int size() {
		return numberOfElements;
		
	}

	@Override
	public boolean isEmpty() {
		return size()== 0;
	}

	@Override
	public boolean contains(Object o) {
		for(int i = 0; i<size();i++) {
		}
		return false;
	}

	@Override
	public boolean add(Object element) {
		boolean bool = false;
		checkElement(element);
		if(this.isEmpty()== true){
			head = new Node(element, null);	
			bool=true;
			}
		else {
			Node last = getNode(size()-1);
			last.next = new Node(element, null);
			}		
		numberOfElements++;
		return bool;
	}

	@Override
	public boolean remove(Object o) {
		boolean bool = false;
		checkElement(o);
		checkState();
		int position = this.search(o);
		if (position != -1)
			this.remove(position);	
			bool=true;	
		return bool;
	}

	@Override
	public Object get(int index) {
		return get(index);
	}

	@Override
	public Object set(int index, Object element) {
		return null;
	}

	@Override
	public void add(int index, Object element) {
		for(int i=0; i<size();i++) {
			if(i==index)
				add(element);
		}
	}

	@Override
	public Object remove(int index) {
		for(int i=0;i<size();i++) {
			if(get(i)==get(index))
				remove(i);
		}
		return remove(index);
	}

	@Override
	public void clear() {
		for(int i=0; i<size();i++) {
			remove(i);
		}
	}

	@Override
	public int indexOf(Object o) {
		int contador = 0;
		for(int i = 0;i<size(); i++ ) {
			if(get(i)!= o)
				contador++;
		}
		return contador;
	}

	
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder("[");
		Node node = head;
		if (this.isEmpty()==false){
		     for ( int i = 0; i <size()-1; i ++){
			     sb.append(node.element.toString()).append(", ");
			     node=node.next;}
		sb.append(node.element.toString());
		}
		sb.append("]");
		return sb.toString();	
		
	}
	
	@Override
	public int hashCode(){
		int hashCode = 1;
	      for(Node node = head ; node!= null; node= node.next)
	          hashCode = 31 * hashCode + (node == null ? 0 : node.hashCode());
		return  hashCode;
	}
	
	@Override
	public boolean equals(Object o){
		if(o == this)
			return true;
		if(!(o instanceof List))
			return false;
		List other = (List) o;
		if (this.size() != other.size())
			return false;
		int index= 0;
		for (Node node = head ; node!= null; node= node.next)
			if (!(node.element.equals(other.get(index))))
				return false;
			index ++;
		return true;
	}
	
	private Node getNode(int index){
		if ( index <0)
			throw new RuntimeException ( "Error el par�metro no puede ser negativo");
		Node node = head;
		int position = 0;
		while (position < index){
			node = node.next;
			position++;}
		return node;		
	}
	
	private int search(Object element){
		Node node = head;
		int position = 0;
		while (position < size()){
			if ( node.element.equals(element))
				return position;
			node = node.next;
			position++;	}
		return position;}		
	
	
	private void checkElement(Object object){
		if ( object == null)			
			throw new IllegalArgumentException("Error el par�metro no puede ser null");	}
	
	private void checkState(){
		if (isEmpty())			
			throw new IllegalStateException("Error la lista esta vacia");}
	//redefinir equals, hashCode y toString
	
}
