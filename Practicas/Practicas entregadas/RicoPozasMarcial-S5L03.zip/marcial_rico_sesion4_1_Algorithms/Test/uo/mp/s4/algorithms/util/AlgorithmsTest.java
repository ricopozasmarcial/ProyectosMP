package uo.mp.s4.algorithms.util;

import static org.junit.Assert.*;

import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Dvd;

public class AlgorithmsTest {

	@Test
	public void testSearchInteger() {
		Object[] vectorInteger = {10,20,30,40};
		assertEquals(2, Algorithms.search(vectorInteger, 30));
		assertEquals(1, Algorithms.search(vectorInteger, 20));
		assertEquals(0, Algorithms.search(vectorInteger, 10));
		assertEquals(-1, Algorithms.search(vectorInteger, 80));
	}

	
	@Test
	public void testSearchString() {
		Object[] vectorString = {"hola", " que", "tal"};
		assertEquals(0, Algorithms.search(vectorString, "hola"));
		assertEquals(1, Algorithms.search(vectorString, " que"));
		assertEquals(2, Algorithms.search(vectorString, "tal"));
		assertEquals(-1, Algorithms.search(vectorString, "adios"));
	}
	
	@Test
	public void testSearchCd() {
		Cd cd = new Cd("Come Together","Beatles",4,70,10,true);
		Cd cd1 = new Cd("Cancion1", "Artista1", 5, 80,10,true);
		Cd cd2 = new Cd("Cancion22", "Artista21", 52, 820,120,true);
		Object[] vectorCd = {cd, cd1};
		assertEquals(0,Algorithms.search(vectorCd, cd));
		assertEquals(1,Algorithms.search(vectorCd, cd1));
		assertEquals(-1,Algorithms.search(vectorCd, cd2));
	}
	
	@Test
	public void testSearchDvd() {
		Dvd dv1 = new Dvd("theTitle", "theDirector", 120, 60);
		Dvd dv2 = new Dvd("theTitle2", "theDirector2", 1202, 602);
		Dvd dv3 = new Dvd("theTitle22", "theDirector22", 12022, 602);
		Object[] vectorDvd = {dv1, dv2};
		assertEquals(0,Algorithms.search(vectorDvd, dv1));
		assertEquals(1,Algorithms.search(vectorDvd, dv2));
		assertEquals(-1,Algorithms.search(vectorDvd, dv3));

	}
	
	@Test 
	public void testSearchMixto() {
		Cd cd = new Cd("Come Together","Beatles",4,70,10,true);
		Dvd dv1 = new Dvd("theTitle", "theDirector", 120, 60);
		Object[] vectorMixto = {cd, dv1, 1, "hola"};
		assertEquals(0,Algorithms.search(vectorMixto, cd));
		assertEquals(1,Algorithms.search(vectorMixto, dv1));
		assertEquals(2,Algorithms.search(vectorMixto, 1));
		assertEquals(3,Algorithms.search(vectorMixto, "hola"));
		assertEquals(-1,Algorithms.search(vectorMixto, "adios"));
	}
}
