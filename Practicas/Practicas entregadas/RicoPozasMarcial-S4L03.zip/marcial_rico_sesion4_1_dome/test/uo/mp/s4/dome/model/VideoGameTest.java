package uo.mp.s4.dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s4.dome.model.VideoGame;
import uo.mp.s4.dome.model.VideoGame.Platforms;

public class VideoGameTest {
	
	private VideoGame vg;
	
	@Before
	public void setUp(){
		vg = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",0);
	}

	@Test
	public void testVideoGame() {
		//caso1: se crea un objeto correctamente
		assertEquals("The Last Guardian", vg.getTitle());
		assertEquals("Marcial Rico", vg.getOwner());
		assertEquals("Excelente Juego", vg.getReview());
		assertEquals(Platforms.PLAYSTATION, vg.getPlatform());
		assertEquals("TEAM ICO", vg.getAuthor());
		
		
		//caso2:falla el due�o
		try {
			VideoGame vg1 = new VideoGame("The Last Guardian", null, "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",0);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso3: falla el comentario
		try {
			VideoGame vg1 = new VideoGame("The Last Guardian", "Marcial Rico", null, Platforms.PLAYSTATION, 4, "TEAM ICO",0);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso4: falla la plataforma
		try {
			VideoGame vg1 = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente juego", null, 4, "TEAM ICO",0);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso5: falla el numero de jugadores
		try {
			VideoGame vg1 = new VideoGame("The Last Guardian", "Marcial Rico","Excelente juego", Platforms.PLAYSTATION, -9, "TEAM ICO",0);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso6: falla el autor
		try {
			VideoGame vg1 = new VideoGame("The Last Guardian", "Marcial Rico", null, Platforms.PLAYSTATION, 4, null,0);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
	}
	
	
	@Test
	public void testEquals() {
		//caso1: el objeto introducido es igual al que se compara
		vg = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",0);
		assertTrue(vg.isEqualTo(vg));
		
		//caso2: se le pasa un objeto distinto al que se compara
		VideoGame vg1 = new VideoGame("Call Of Duty", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",0);
		assertFalse(vg1.isEqualTo(vg));
		
		//se introduce un objeto vacio
		
		VideoGame vg2 =null;
		try {
			vg.isEqualTo(vg2);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
	}

}
