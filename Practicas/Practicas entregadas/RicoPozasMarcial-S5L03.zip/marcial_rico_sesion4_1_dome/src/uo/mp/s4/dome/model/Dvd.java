package uo.mp.s4.dome.model;

import java.io.PrintStream;

public class Dvd extends Item  {
	private String director;
	public Dvd(String theTitle, String theDirector, int time, double price) {		
		super(theTitle, time, price);
		setDirector(theDirector);
	}

	/**
	 * Asigna valor al atributo director
	 * @param nombre del director, de tipo String
	 */
	public void setDirector(String director) {
		if (director != null)
			this.director = director;
	}

	/**
	 * Devuelve el valor del atributo Director
	 * @return nombre del director, de tipo String
	 */
	public String getDirector() {
		return this.director;
	}
	
	/**
	 * metodo printResponsable de la clase Dvd
	 */
	public void printResponsable(PrintStream out) {
		out.println(getDirector() + " ");
	}
	

	/**
	 * Imprime en el objeto out los valores de los atributos 
	 * @param out 
	 */
	public void print(PrintStream out) {
		out.print("DVD:");
		super.print(out);
		out.println(" " + getDirector());
		
	}

	@Override
	public boolean isEqualTo(Item item) {
		if(item instanceof Dvd) {
			if(item.getTitle().equals(this.getTitle()) && ((Dvd) item).getDirector().equals(this.getDirector()))
				return true; 
			else
				return false;
			}
		return false;
		}

	@Override
	public double calculatePrice(Item item) {
		if(item instanceof Dvd) {
			return item.getPrice();
		}
		return 0;
	}

	@Override
	public String code(Item item) {
		if(item instanceof Dvd) {
			String sCadena = getTitle().substring(0, 3);
			String true_false = new String();
			if(item.getOwn()==true) {
				true_false = "T";
			}
			else {
				true_false = "F";
			}
			sCadena = sCadena+true_false;
			return sCadena;
		}
		else
			return null;
	}

}
