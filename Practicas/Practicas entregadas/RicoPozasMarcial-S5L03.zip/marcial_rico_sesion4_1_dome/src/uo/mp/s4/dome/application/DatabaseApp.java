/**
 * 
 */
package uo.mp.s4.dome.application;



import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Database;
import uo.mp.s4.dome.model.Dvd;
import uo.mp.s4.dome.model.VideoGame;
import uo.mp.s4.dome.model.VideoGame.Platforms;

/**
 * @author Power Service
 *
 */
public class DatabaseApp {
	private Database db;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new DatabaseApp().run();

	}
	public void run() {
		db = new Database();
		Cd cd1 = new Cd("Night Visions", "Imagine Dragons", 14, 120,0,true);
		Cd cd2 = new Cd("Meteroa", "Linkin Park", 10, 100,0,true);
		Cd cd3 = new Cd("La Veneno Greatest Hits ", "Cristina la veneno", 54, 320,0,true);
		Dvd dvd1 = new Dvd("Titanic", "James Cameron", 150,0);
		Dvd dvd2 = new Dvd("Sharknado", "Pedro Almodovar", 550,0);
		Dvd dvd3 = new Dvd("Titanica", "Yeims Camaron de la isla", 650,0);
		VideoGame vg1 = new VideoGame("CoD", "Marcial Rico", "Buen Juego", Platforms.XBOX, 4, "ACTIVISION",0);
		VideoGame vg2 = new VideoGame("Child of Light", "Marcial Rico", "Gran Juego", Platforms.NINTENDO, 1, "UBISFOT",0);
		VideoGame vg3 = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",0);
		db.add(cd1);
		db.add(cd2);
		db.add(cd3);
		db.add(dvd1);
		db.add(dvd2);
		db.add(dvd3);
		db.add(vg1);
		db.add(vg2);
		db.add(vg3);
		System.out.println("EL numero de objetos adquiridos es : " + db.numberOfItemsOwned());
		db.printResponsables(System.out);
		db.list(System.out);
		System.out.print(db.generateCode());
	}
}
