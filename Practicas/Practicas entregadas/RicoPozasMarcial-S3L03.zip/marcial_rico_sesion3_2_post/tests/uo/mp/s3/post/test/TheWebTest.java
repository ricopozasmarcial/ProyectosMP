package uo.mp.s3.post.test;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertLinesMatch;

import java.util.ArrayList;

import org.junit.*;

import uo.mp.s3.post.model.Post;
import uo.mp.s3.post.model.TheWeb;

public class TheWebTest {

	private TheWeb w1;
	private Post p1;
	private ArrayList<String> comentarios;
	@Before
	public void setUp(){
		
		comentarios = new ArrayList<String>();
		comentarios.add("como mola");
		comentarios.add("me encanta");
		w1 = new TheWeb();
		p1 = new Post(comentarios, 'q');
	}
	
	@Test
	public void testAdd() {
		
		//caso1: se a�ade un post
		w1.addPost(p1);
		assertEquals(p1, w1.getPosts().get(0));
		
		//caso2: se intenta a�adir un post null
		p1 = null;
		try {
			w1.addPost(p1);
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
	}

	@Test
	public void testFiltrarUsuario() {
		
		//creamos algunos posts bajo el usuario 'q'
		
		Post p0 = new Post(comentarios, 'q');
		Post p2 = new Post(comentarios, 'q');
		Post p3 = new Post(comentarios, 'q');
		Post p4 = new Post(comentarios, 'q');
		ArrayList<Post> aux = new ArrayList<Post>();
		w1.addPost(p0);
		w1.addPost(p2);
		w1.addPost(p3);
		w1.addPost(p4);
		aux.add(p0);
		aux.add(p2);
		aux.add(p3);
		aux.add(p4);
		assertEquals(aux,w1.filtrarUsuario('q'));
	}
}
