package uo.mp.s3.post.test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.*;
import uo.mp.s3.post.model.Photo;

public class PhotoTest {
	private Photo ph;
	private ArrayList<String> comentarios;
	
	@Before
	public void setUp(){
		
		comentarios = new ArrayList<String>();
		comentarios.add("como mola");
		comentarios.add("me encanta");
		ph = new Photo("TARDE EN FAMILIA", "JPG.1234",comentarios, 'i');
		
	}

	@Test
	public void testConstructor() {
		
		//caso1: se construye el objeto bien
		assertEquals('i', ph.getIdentifier());
		assertEquals("TARDE EN FAMILIA", ph.getTitle());
		assertEquals("JPG.1234", ph.getNombrePhoto());
		assertEquals(comentarios, ph.getCommentList());
		
		//caso2: el nombre de la foto es null
		try{
			Photo ph2 = new Photo(ph.getTitle(), null, comentarios, ph.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso2: el titulo del post es null
		try{
			Photo ph2 = new Photo(null, ph.getNombrePhoto(),comentarios, ph.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso4 el titulo del post es un espacio en blanco
		try{
			Photo ph2 = new Photo(" ", ph.getNombrePhoto(),comentarios, ph.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
		
		//caso5: el nombre de la foto es un espacio en blanco
		try{
			Photo ph2 = new Photo(ph.getTitle(), " ", comentarios, ph.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("parametro invalido", iae.getMessage());
		}
	}
	
}
