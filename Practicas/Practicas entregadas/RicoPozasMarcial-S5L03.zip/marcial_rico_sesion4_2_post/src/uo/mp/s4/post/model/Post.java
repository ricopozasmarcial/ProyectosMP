package uo.mp.s4.post.model;

import java.io.PrintStream;
import java.util.ArrayList;

public class Post {
	//constantes
	public final static int DEFAULT_LIKES = 0;
	
	//atributos
	private int likes;
	private ArrayList<String> commentList;
	private char identifier;
	
	
	/**
	 * constructor por ddfecto de objetos de la clase post
	 */
	public Post() {
		super();
	}
	
	/**
	 * contructor con parametros de objetos de la clase post
	 * @param comentario, un string que indica el comentario del post
	 * @param idUsuario, un char que indica el id del usuario
	 */
	public Post(ArrayList<String> comentarios, char idUsuario){
		this();
		setLikes(DEFAULT_LIKES);
		setCommentList(comentarios);
		setIdentifier(idUsuario);
	}
	
	/**
	 * metodo set del atributo identifier
	 * @param idUsuario, un char que asigna el identificador de usuario
	 */
	protected void setIdentifier(char idUsuario) {
		if( idUsuario == ' ') {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.identifier = idUsuario;
		}
		
	}
	
	/**
	 * metodo set del atributo commentList
	 * @param defaultCommentList, la lista po defecto del atributo
	 */
	protected void setCommentList(ArrayList<String> defaultCommentList) {
		if(defaultCommentList == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		this.commentList = defaultCommentList;
	}

	/**
	 * metodo set del atributo likes
	 * @param defaultLikes, un entero que asocia el numero de likes por defecto
	 */
	
	protected void setLikes(int defaultLikes) {
		if(defaultLikes <0) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.likes = defaultLikes;
		}
	}
	
	/**
	 * metodo get del atributo likes
	 * @return el valor de likes
	 */
	public int getLikes() {
		return this.likes;
	}
	
	/**
	 * metodo get del atributo commentList
	 * @return el valor de commentList
	 */
	public ArrayList<String> getCommentList() {
		return this.commentList;
	}
	
	/**
	 * metodo get del atributo identifier
	 * @return el valor de identifier
	 */
	public char getIdentifier() {
		return this.identifier;
	}
	
	public void add(String comentario) {
		commentList.add(comentario);
	}
	
	public void printComments(PrintStream out) {
		for(String comentarios: commentList) {
			out.print(comentarios);
		}
	}
}
