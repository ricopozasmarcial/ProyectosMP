package sesion2.wordAnalyzer.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion2.wordaAnalyzer.WordAnalyzer;

public class WordAnalyzerTest {
	private WordAnalyzer empty;
	
	@Before
	public void setUp() {
		empty = new WordAnalyzer("");
	}
	@Test
	public void testFirstRepeatedCharacter() {
		//caso1: el caracter repetido este al principio
		WordAnalyzer analyzer = new WordAnalyzer("aaabcde");
		assertEquals('a',analyzer.firstRepeatedCharacter());
	
		//caso2: el caracter repetido este al final
		analyzer = new WordAnalyzer("abcdeee");
		assertEquals('e',analyzer.firstRepeatedCharacter());
		
		//caso3: el caracter repetido este en medio
		analyzer = new WordAnalyzer("abcccde");
		assertEquals('c',analyzer.firstRepeatedCharacter());
		
		
		//caso4: hay mas de un grupo de caracteres repetidos
		analyzer = new WordAnalyzer("aaabcccde");
		assertEquals('a',analyzer.firstRepeatedCharacter());
		
		//caso5: no hay grupos de caracteres repetidos
		analyzer = new WordAnalyzer("abcde");
		assertEquals(0,analyzer.firstRepeatedCharacter());
		
		//caso6: la cadena es una cadena vacia
		assertEquals(0,empty.firstRepeatedCharacter());
	}

	@Test
	public void testFirstMultipleCharacter() {
		fail("Not yet implemented");
	}

	@Test
	public void testCountGroupsOfRepeatedCharacters() {
		fail("Not yet implemented");
	}

}
