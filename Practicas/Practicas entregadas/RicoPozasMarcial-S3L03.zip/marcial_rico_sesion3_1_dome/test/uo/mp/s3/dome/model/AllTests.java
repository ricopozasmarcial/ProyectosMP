package uo.mp.s3.dome.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CdTest.class, DatabaseTest.class, DvdTest.class, VideoGameTest.class })
public class AllTests {

}
