/**
 * 
 */
package uo.mp.s4.dome.model;

import java.io.PrintStream;

/**
 * @author Power Service
 *
 */
public class Book extends Item implements Borrowable{
	
	private String author;
	private String Isbn;
	private String editorial;
	private boolean isAvailable;
	
	/**
	 *  constructor con parametros de objetos de la clase Book
	 */
	public Book(String theTitle, double price, String theAuthor, String theIsbn, String theEditorial, boolean isAvailable) {
		super(theTitle, price);
		setAuthor(theAuthor);
		setIsbn(theIsbn);
		setEditorial(theEditorial);
		setIsAvailable(isAvailable);
		}
	
	/**
	 * metodo get del atributo isAvailable
	 * @return el valor de isAvailable
	 */
	public boolean getIsAvailable() {
		return this.isAvailable;
	}
	
	/**
	 * metodo get del atributo Author
	 * @return el nombre del autor
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * metodo get del atributo Isbn
	 * @return el valor de Isbn
	 */
	public String getIsbn() {
		return Isbn;
	}
	
	/**
	 * metodo get del atributo editorial
	 * @return el valor de editorial
	 */
	public String getEditorial() {
		return editorial;
	}
	
	/**
	 * metodo set del atributo author
	 * @param author, un String que establece el nombre del autor
	 */
	private void setAuthor(String author) {
		if(author == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		this.author = author;
	}
	
	/**
	 * metodo set del atributo isbn
	 * @param isbn, un String que  establece el isbn del libro
	 */
	private void setIsbn(String isbn) {
		if(isbn == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		Isbn = isbn;
	}

	private void setEditorial(String editorial) {
		if(editorial == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		this.editorial = editorial;
	}
	
	/**
	* M�todo set del atributo isAvailable
	* @param isAvailable, un booleano que indica si el objeto esta disponible
	*/
	private void setIsAvailable(boolean isAvailable) {
		this.isAvailable=isAvailable;
		}
	
	/**
	 * metodo printResponsable de la clase Book
	 */
	@Override
	public void printResponsable(PrintStream out) {
		out.println(getAuthor() + " ");
		
	}

	@Override
	public boolean isEqualTo(Item item) {
		if(item instanceof Book) {
			if(item.getTitle().equals(this.getTitle()) && ((Book) item).getAuthor().equals(this.getAuthor()))
			    return true; 
			else
				return false;
		}
		return false;
	}

	@Override
	public double calculatePrice(Item item) {
		if(item instanceof Book) {
			return item.getPrice();
		}
		else {
			return 0;
		}
	}

	@Override
	public String code(Item item) {
		if(item instanceof Book) {
			String sCadena = getTitle().substring(0, 3);
			String true_false = new String();
			if(item.getOwn()==true) {
				true_false = "T";
			}
			else {
				true_false = "F";
			}
			sCadena = sCadena+true_false;
			return sCadena;
		}
		else
			return null;
	}

	/**
	* M�todo que devuelve si el libro esta disponible 
	*/
	
	public boolean isAvailableToBorrow() {
		if (( getOwn() == true)&& (isAvailable==true))
	        return true; 
		return false;
		}
	/**
	* M�todo que presta un libro
	*/
	
	public boolean borrow() {
	     boolean previousValue = isAvailable;
	     isAvailable = false;
	     return previousValue; 
	     }
	/**
	* M�todo que devuelve un libro
	*/
	
	public void giveBack() {
	     setIsAvailable(true); 
	     }
	
}
