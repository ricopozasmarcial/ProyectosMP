package uo.mp.s4.post.model;

import java.util.ArrayList;

public class Photo extends Post{
	
	//atributos
	private String nombrePhoto;
	private String title;
	
	/**
	 * constructor con parametros de objetos de la clase Photo
	 *
	 * @param nombre, un String que asigna un nombre
	 * @param foto, un String que asigna el nombre de la foto
	 * @param comentario, un String que asigna un comentario
	 * @param idUsuario, un char que asigna un id de usuario
	 */
	public Photo(String title, String nombrePhoto,ArrayList<String> comentarios, char idUsuario) {
		super(comentarios, idUsuario);
		setNombrePhoto(nombrePhoto);
		setTitle(title);
	}
	
	/**
	 * metodo set del atributo nombrePhoto
	 * 
	 * @param nombrePhoto, un String que asigna el nombre de la foto
	 */
	private void setNombrePhoto(String nombrePhoto) {
		if(nombrePhoto== " " || nombrePhoto == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.nombrePhoto = nombrePhoto;
		}
	}
	
	/**
	 * metodo get del atributo nombrePhoto
	 * 
	 * @return el valor de nombrePhoto
	 */
	public String getNombrePhoto() {
		return this.nombrePhoto;
	}
	
	/**
	 * metodo set del atributo title
	 * 
	 * @param titulo, un String que indica el nombre del titulo
	 */
	private void setTitle(String titulo) {
		if(titulo== " " || titulo == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.title = titulo;
		}
	}
	
	/**
	 * metodo get del atributo title
	 * 
	 * @return el valor de title
	 */
	public String getTitle() {
		return this.title;
	}
}
