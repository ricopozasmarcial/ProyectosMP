package uo.mp.s4.dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.s4.dome.model.Cd;
import uo.mp.s4.dome.model.Database;
import uo.mp.s4.dome.model.Dvd;
import uo.mp.s4.dome.model.VideoGame;
import uo.mp.s4.dome.model.VideoGame.Platforms;

public class DatabaseTest {
	private Database db;
	private Cd cd;
	private Dvd dvd;
	private VideoGame vg;
	
	@Before
	public void setUp() {
		db = new Database();
		cd = new Cd("YELLOW SUBMARINE", "BEATLES",70,4,10.0,true);
		dvd = new Dvd("Star Wars", "George Lucas", 210,50);
		vg = new VideoGame("The Last Guardian", "Marcial Rico", "Excelente Juego", Platforms.PLAYSTATION, 4, "TEAM ICO",880);
		
	}
	@Test
	public void testAdd() {
		//caso1: a�adimos un objeto dvd
		db.add(dvd); //su posicion dentro del array vacio sera 0
		assertEquals(dvd, db.getItems().get(0));
		
		//caso2: dentro del mismo array a�adimos un objeto cd
		db.add(cd); //su posicion dentro del array sera 1
		assertEquals(cd, db.getItems().get(1));
		
		//caso3: intetamos a�adir un objeto videoGame cuya posicion sera 2
		db.add(vg);
		assertEquals(vg, db.getItems().get(2));
		
		//caso4: se intenta a�adir un objeto null
		try {
			db.add(null);
			fail();
		}
		catch(IllegalArgumentException rte) {
			assertEquals("Parametro invalido", rte.getMessage());
		}
	}

	@Test
	public void testNumberOfItemsOwned() {
		//a�adimos ningun objeto a la dataBase y ejecutamos
		assertEquals(0,db.numberOfItemsOwned());
		
		//a�adimos 2 objetos a la database y ejecutamos
		db.add(cd);
		db.add(dvd);
		db.add(vg);
		assertEquals(3,db.numberOfItemsOwned());
		
		//nota: no es necesario que se pruebe con un objeto null puesto que el metodo add 
		//se encarga de no a�adirlos
	}

	@Test
	public void testList() {
		db.add(cd);
		db.add(dvd);
		db.add(vg);
		dvd.setOwn(true);
		db.list(System.out);
	}

	@Test
	public void testSearchItem() {
		//caso1: la lista contiene un objeto en la posicion 0
		db.add(cd);
		assertEquals(0, db.searchItem(cd));
		
		//caso2: a�adimos otro objeto a la dataBase y buscamos el nuevo objeto
		db.add(dvd);
		assertEquals(1,db.searchItem(dvd));
		
		//caso3: intentamos buscar un objeto que no esta a�adido
		Dvd dvd1 = new Dvd("Indiana Jones", "George Lucas", 120,0);
		assertEquals(-1, db.searchItem(dvd1));
		
		//caso4: se intenta buscar un objeto null
		try {
			db.searchItem(null);
			fail();
		}
		catch(IllegalArgumentException rte) {
			assertEquals("Parametro incorrecto", rte.getMessage());
		}
	}
	
	@Test
	public void printResponsables() {
		//caso1: tenemos un cd y un dvd a�adidos al array y ejecutamos el metodo
		db.add(cd);
		db.add(dvd);
		db.add(vg);
		db.printResponsables(System.out); //comprobamos que los responsables son corrector por consola
	}
	
	@Test
	public void TestTotalValue() {
		//caso1: los 3 objetos a a�adir tienen due�o
		Database db1 = new Database();
		vg.setOwn(true);
		cd.setOwn(true);
		dvd.setOwn(true);
		db1.add(cd);
		db1.add(dvd);
		db1.add(vg);
		assertEquals(940.0, db1.totalValue(),0.1); //los precios seran de 940 euros
		
		//caso2: uno de los objetos no tiene due�o
		db1 = new Database();
		vg.setOwn(false);
		cd.setOwn(true);
		dvd.setOwn(true);
		db1.add(cd);
		db1.add(dvd);
		db1.add(vg);
		assertEquals(60.0, db1.totalValue(),0.1);
	}
	
	@Test
	public void testSearch() {
		//caso1: a�adimos unos objetos a la base y buscamos 1
		Database db1 = new Database();
		db1.add(cd);
		db1.add(vg);
		assertEquals(vg, db1.search(vg));
		
		//caso2: buscamos un objeto fuera de la database
		assertNull(db1.search(dvd));
		
		
		
	}
}
