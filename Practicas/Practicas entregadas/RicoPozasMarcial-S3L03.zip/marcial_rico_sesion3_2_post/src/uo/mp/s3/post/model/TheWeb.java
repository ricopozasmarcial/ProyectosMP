package uo.mp.s3.post.model;

import java.io.PrintStream;
import java.util.ArrayList;

public class TheWeb {
	
	//atributos
	private ArrayList<Post> posts;
	
	/**
	 * constructor de objetos de la  clase theWeb
	 */
	public TheWeb() {
		posts = new ArrayList<Post>();
	}
	
	
	/**
	 * metodo set del atributo posts
	 * 
	 * @param publicaciones, un arrayList que asigna la lista de publicaciones
	 */
	private void setPosts(ArrayList<Post> publicaciones) {
		if(publicaciones == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			this.posts = publicaciones;
		}
	}
	
	/**
	 * metodo get del atributo posts
	 * 
	 * @return el valor de posts
	 */
	public ArrayList<Post> getPosts(){
		return this.posts;
	}
	
	/**
	 * metodo add de la clase theWeb
	 */
	public void addPost(Post publicacion) {
		if(publicacion == null) {
			throw new IllegalArgumentException("parametro invalido");
		}
		else {
			posts.add(publicacion);
		}
	}
	
	/**
	 * metodo printPosts de la clase theWeb
	 * 
	 * @param out, un PrintStream que imprime el objeto por pantalla
	 */
	public void printPosts(PrintStream out) {
		for(Post publicaciones :posts) {
			if(publicaciones instanceof Message ) {
				out.println("USUARIO :" + publicaciones.getIdentifier());
				out.println("NUMERO DE LIKES: " + publicaciones.getLikes());
				out.println("COMENTARIOS :" + publicaciones.getCommentList());
				out.println("MENSAJE: " +((Message) publicaciones).getTexto());
				out.println("\n");
			}
			else {
				out.println("USUARIO :" + publicaciones.getIdentifier());
				out.println("NUMERO DE LIKES: " + publicaciones.getLikes());
				out.println("COMENTARIOS :" + publicaciones.getCommentList());
				out.println("ARCHIVO :" + ((Photo) publicaciones).getNombrePhoto());
				out.println("TITULO DEL POST :" + ((Photo)publicaciones).getTitle());
				out.println("\n");

			}
		}
	}
	
	/**
	 * metodo filtrarUsuario de la clase theWeb
	 * 
	 * @param user, un char que indica el usuario sobre el que se recogen los posts
	 * @return lista, un ArrayList que contiene los posts del usuario
	 */
	public ArrayList<Post> filtrarUsuario(char user){
		if(user == ' ' ) {
			throw new IllegalArgumentException("Parametro invalido");
		}
		else {
			ArrayList<Post> lista = new ArrayList<Post>();
			for(Post publicaciones: posts) {
				if(user == publicaciones.getIdentifier()) {
					lista.add(publicaciones);
				}
			}
		return lista;
		}
	}
}
