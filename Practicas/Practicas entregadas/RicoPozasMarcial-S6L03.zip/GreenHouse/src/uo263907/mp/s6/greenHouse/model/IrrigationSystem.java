/**
 * 
 */
package uo263907.mp.s6.greenHouse.model;

/**
 * @author Power Service
 *
 */
public class IrrigationSystem {

	public final static String OFF = "apagado";
	public final static String LOW = "bajo";
	public final static String MEDIUM = "medio";
	public final static String HIGH = "alto";
	
	private String state;
	
	public IrrigationSystem(String state) {
		setState(state);
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
			this.state = state;
	}
	
	/**
	 * metodo que incrementa  y cambia el estado del sistema de riego
	 * @param state, un string que indica el estado del sistema
	 */
	public void increaseState() {
		if(getState() == OFF)
			setState(LOW);
		else if(getState() == LOW)
			setState(MEDIUM);
		else if(getState()== MEDIUM)
			setState(HIGH);
		else {
			setState(HIGH);
		}
			
	}
	
	/**
	 * metodo que disminuye y cambia el estado del sistema de riego
	 * @param state un string que indica el estado del sistema de riego
	 */
	public void decreaseState() {
		if(getState() == HIGH)
			setState(MEDIUM);
		else if(getState() == MEDIUM)
			setState(LOW);
		else if(getState()== LOW)
			setState(OFF);
		else {
			setState(OFF);
		}
	}
	
}
