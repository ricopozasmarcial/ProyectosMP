package uo.mp.s3.post.application;

import java.util.ArrayList;

import uo.mp.s3.post.model.Message;
import uo.mp.s3.post.model.Photo;
import uo.mp.s3.post.model.Post;
import uo.mp.s3.post.model.TheWeb;

public class PostApp {
	private TheWeb twb;
	

	public static void main(String[] args) {
		new PostApp().run();

	}
	
	public void run() {
		twb = new TheWeb();
		Photo ph1 = new Photo("FLOR EN EL CAMPO", "PNG.1234",null,'a');
		Photo ph2 = new Photo("COCHE EN LA CIUDAD", "PNG.2355",null, 'q');
		Message ms1 = new Message("Hola chicos que tal todo", null , 'q');
		Message ms2 = new Message("Todo bien", null, 'a');
		
		twb.addPost(ms2);
		twb.addPost(ms1);
		twb.addPost(ph2);
		twb.addPost(ph1);
		
		
		imprimirLista(twb.filtrarUsuario('q'));
		
	}
	
	public void imprimirLista(ArrayList<Post>lista) {
		for(Post publicaciones: lista) {
			if(publicaciones instanceof Message ) {
				System.out.println("USUARIO :" + publicaciones.getIdentifier());
				System.out.println("NUMERO DE LIKES: " + publicaciones.getLikes());
				System.out.println("COMENTARIOS :" + publicaciones.getCommentList());
				System.out.println("MENSAJE: " +((Message) publicaciones).getTexto());
				System.out.println("\n");
			}
			else {
				System.out.println("USUARIO :" + publicaciones.getIdentifier());
				System.out.println("NUMERO DE LIKES: " + publicaciones.getLikes());
				System.out.println("COMENTARIOS :" + publicaciones.getCommentList());
				System.out.println("ARCHIVO :" + ((Photo) publicaciones).getNombrePhoto());
				System.out.println("TITULO DEL POST :" + ((Photo)publicaciones).getTitle());
				System.out.println("\n");

			}
		}
	}
}
