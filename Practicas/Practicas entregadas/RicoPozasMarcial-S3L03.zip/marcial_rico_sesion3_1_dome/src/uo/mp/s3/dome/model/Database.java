package uo.mp.s3.dome.model;

import java.io.PrintStream;
import java.util.ArrayList;

public class Database {
	private ArrayList<Item> items;
	
	public Database() {
		items = new ArrayList<Item>();
	}
	
	
	/**
	 * metodo getItems de la clase dataBase
	 * @return el valor de Items
	 */
	public ArrayList<Item> getItems(){
		return items;
	}
	
	/**
	 * a�ade un elemento a la base de datos
	 * @param elemento a a�adir, de tipo item
	 */
	public void add(Item itemToAdd) {
		if(itemToAdd== null) {
			throw new IllegalArgumentException("Parametro invalido");
		}
		else {
			items.add(itemToAdd);
		}
	}
	
	private void checkNotNull(Item item) {
		if(item == null)
			throw new IllegalArgumentException("parametro item null");
		}
	
	/**
	 * @return numero de items que tiene el propietario
	 */
	public int numberOfItemsOwned() {
		int count = 0;
		for(Item itemToCount: items) {
			if(itemToCount != null) {
				count++;
			}
		}
		return count;
	}
	
	/**
	 * vuelca en el objeto out los datos de los atributos de todos los elementos de la BBDD
	 * @param out, objeto donde se vuelca la info.
	 */
	public void list(PrintStream out) {
		for(Item itemToList: items) {
			itemToList.print(out);
		}
	}
	
	/**
	 * metodo searchItem de la clase database que busque en la 
	 * base de datos un item recibido como par�metro y devuelva la posici�n que ocupa o bien 
	 * -1 si no lo ha encontrado
	 * @param theItem, un objeto de tipo Item que es el que se desea buscar
	 * 
	 * @return -1 si el objeto no es encontrado
	 */
	public int searchItem(Item theItem) {
		if(theItem == null) {
			throw new IllegalArgumentException("Parametro incorrecto");
		}
		else {
		for(Item itemToFind: items) {
			if(itemToFind == theItem) {
				return items.indexOf(itemToFind);
			}
			}	
		}
		return -1;
	}
	
	/**
	 * metodo  printResponsables de la clase Database, que vuelca en un objeto out 
	 * todos los responsables de los objetos que encuentra en la base de datos
	 */
	public void printResponsables(PrintStream out) {
		for(Item itemsToPrint: items) {
			if(itemsToPrint instanceof Dvd) {
				out.print(((Dvd) itemsToPrint).getDirector() + " " + "\n");
			}
			else if(itemsToPrint instanceof Cd) {
				out.print(((Cd) itemsToPrint).getArtist() + " " + "\n");
			}
			else {
				out.print(((VideoGame) itemsToPrint).getAuthor());
			}
		}
	}
}
