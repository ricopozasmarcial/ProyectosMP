/**
 * 
 */
package uo263907.mp.s6.greenHouse.model;
import java.io.PrintStream;
import java.util.Random;

/**
 * @author Power Service
 *
 */
public class HumiditySensor implements ElectronicDevice{

	/**
	 * simula la medicion de la humedad
	 * 
	 * @return La humedad medida por el sensor
	 */
	public int getHumidity() {
		Random r = new Random();
		return r.nextInt(50)+20;
	}

	@Override
	public void check(PrintStream out) {
		out.println("Comprobando sensor de humedad");
		
	}

}
