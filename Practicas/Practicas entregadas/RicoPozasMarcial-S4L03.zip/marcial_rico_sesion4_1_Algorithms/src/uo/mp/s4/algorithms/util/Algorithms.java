package uo.mp.s4.algorithms.util;

public class Algorithms {
	
	/**
	 * metodo que busca un objeto en un array de objetos
	 * 
	 * @param array de objetos
	 * @param objeto a buscar en el array
	 * @return posicion en el array en la que ha encontrado el objeto igual al recibido como parametro
	 */
	public static int search(Object[] vector, Object objectToSearch) {
		for(int i=0; i<vector.length;i++) {
			if(vector[i].equals(objectToSearch)) {
				return i;
			}
		}
		return -1;
	}
}
