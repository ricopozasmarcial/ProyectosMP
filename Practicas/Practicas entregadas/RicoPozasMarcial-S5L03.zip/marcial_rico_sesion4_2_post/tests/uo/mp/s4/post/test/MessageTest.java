package uo.mp.s4.post.test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.*;

import uo.mp.s4.post.model.Message;
import uo.mp.s4.post.model.Photo;

public class MessageTest {
	private Message ms;
	private ArrayList<String> comentarios;
	
	@Before
	public void setUp(){
		
		comentarios = new ArrayList<String>();
		comentarios.add("como mola");
		comentarios.add("me encanta");
		ms = new Message("hola mundo", comentarios, 'q');
		
	}

	@Test
	public void testConstructor() {
		
		//caso1: se construye el objeto bien
		
		assertEquals('q', ms.getIdentifier());
		assertEquals("hola mundo", ms.getTexto());
		assertEquals(comentarios, ms.getCommentList());
		
		//caso2: el texto del mensaje es null
		
		try{
			Message ms1 = new Message(null, comentarios, ms.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("Parametro invalido", iae.getMessage());
		}
		
		//caso3: el titulo del post es un espacio en blanco
		
		try{
			 Message ms1 = new Message(" ", comentarios, ms.getIdentifier());
			fail();
		}
		catch(IllegalArgumentException iae) {
			assertEquals("Parametro invalido", iae.getMessage());
		}
	}
	
}