package uo263907.mp.sesion08.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo263907.mp.sesion08.colecciones.ArrayList;
import uo263907.mp.sesion08.colecciones.List;

public class ArrayListTest  extends ListTest{

	@Override
	public List createList() {
		 return new ArrayList();
	}
	
	

}
